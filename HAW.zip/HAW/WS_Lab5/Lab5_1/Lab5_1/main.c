#define _CRT_NO_SECURE_WARNINGS

#include "functions.h"

int main()
{
double matrix_2D[ROWS][COLUMNS] = {
									{1, 2, 3},
									{4, 5, 6}
								  };

double matrix_3D[PLANES][ROWS][COLUMNS] = {
											{ {1,2,3},
											  {4,5,6},
														},
											{ {11,22,33},
											  {44,55,66},
														},
											{ {111,222,333},
											  {444,555,666},
														},
											{ {1111,2222,3333},
											  {4444,5555,6666},
														},
										  };

	int large_array_1D[] = {1, 8, 11, 4, 6, 9, 15, 4, 6, 9, 8};
	int small_array_1D[] = {4, 6, 9, 1, 11};
	int size_large, size_small;
	int result;

//----------------------------------------------------------

	//print_2D_matrix(matrix_2D);
	//print_3D_matrix(matrix_3D);

	size_large = sizeof(large_array_1D) / sizeof(large_array_1D[0]);
	size_small = sizeof(small_array_1D) / sizeof(small_array_1D[0]);
	printf("size_large: %d\n", size_large);
	printf("size_small: %d\n", size_small);

	result = Is_large_1D_array_inside_small_1D_array(
														large_array_1D,
														small_array_1D,
														size_large, size_small);
	printf("result = %d\n", result);
	
	system("pause");
	return 0;
}