#include <stdio.h>
#include <stdlib.h>

#define ROWS 2
#define COLUMNS 3
#define PLANES 4

//***PROTOTYPES***

void print_2D_matrix(double [][COLUMNS]);

void print_3D_matrix(double [][ROWS][COLUMNS]);

int Is_large_1D_array_inside_small_1D_array(
											int large_array_1D[],
											int small_array_1D[],
											int size_large,
											int size_small);