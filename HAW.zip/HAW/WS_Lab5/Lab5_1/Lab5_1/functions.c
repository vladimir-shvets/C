#include "functions.h"

//print 2D_array
void print_2D_matrix(double arr[][COLUMNS])
{
	int i, j;

	//------------------------------------------

	for (i = 0; i < ROWS; i++)
	{
		for (j = 0; j < COLUMNS; j++)
		{
			printf("%6.0f", arr[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}

//print 3D_array
void print_3D_matrix(double arr[][ROWS][COLUMNS])
{
	int i, j, k;

	//----------------------------------------------

	for (k = 0; k < PLANES; k++)
	{
		for (i = 0; i < ROWS; i++)
		{
			for (j = 0; j < COLUMNS; j++)
				printf("%6.0f", arr[k][i][j]);
			printf("\n");
		}
		printf("\n");
	}
}

//function which checks if the small array is into the large array and is it also in consecutive order
int Is_large_1D_array_inside_small_1D_array(
											int large_array_1D[],
											int small_array_1D[],
											int size_large,
											int size_small)
{
	int i = 0,j = 0, k = 0, flag = 1;
	int temp[10] = {0}; //temporary static array which stores the small array values positions in the large array
	
	//--------------------------------------------------------

	// two nested loops: first moves on small_array, second one on the large_array
		while(i < size_small)
		{
			while(j < size_large)
			{
				if (small_array_1D[i] == large_array_1D[j]) //if elements from small and large arrays are equal
				{
					temp[k] = j; // then into temp array we store the value position in the large_array and continue movingthrough array
					k++;
					break;
				}
				j++;
			}
			i++;
		}
		//print out the positions of small_array elements into large_array
		/*for (i = 0; i < size_small; i++)
		{
			printf("%d ", temp[i]);
		}*/

		for (i = 0; i < size_small-1; i++)
		{
			if (temp[i] > temp[i+1]) //comparison the positions into the temp array, at this way we check that elements from small_array are
			{						// all founded and they are in consecutive order
					flag = 0;
					break;
			}
		}
	return flag;
}