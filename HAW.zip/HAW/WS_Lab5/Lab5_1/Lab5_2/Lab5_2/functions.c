#include "functions.h"

//Check for triplet. If all three dice values are equal then return 1, else return 0.
int check_for_triplets(int *arr) 
{
	if (arr[0] == arr[1] && arr[1] == arr[2])
		return 1;
	else return 0;
}

//Check for doubles. If any two dice values are equal then return 1, else return 0.(no triplets would be calculated)
int check_for_doubles(int *arr)
{
	if ((arr[0] == arr[1] || arr[0] == arr[2] || arr[1] == arr[2]) && !check_for_triplets(arr))
		return 1;
	else return 0;
}

//print the dices of 1 throw in appropriate view(like at the lab_asignment example) and print calculated amount of doubles and triplets
void display( char dice [] [HIGHT_OF_ONE_DIE] [WIDTH_OF_DICE], int three_different_throws[])
{
	int same, j = 0, k=0, i=0;
	char screen[HIGHT_OF_DISPLAY][WIDTH_OF_DISPLAY];

	//-----------------------------------------------------------------------
	
	for (same = 0; same < HIGHT_OF_DISPLAY; same++)
	{ 
		j = 0;
		i = 0;
		while(j < WIDTH_OF_DISPLAY)
		{
				screen[same][j] = dice [three_different_throws[i]][same][k];
				j++;
				k++;
				if (dice [three_different_throws[i]][same][k] == '\0' )
					screen[same][j] = ' ';
				
				if (k == WIDTH_OF_DICE-1)
				{
					screen[same][j] = '\t';
					j++;
					k = 0;
					i++;
				}
		}
	}

	for (i = 0; i < HIGHT_OF_DISPLAY; i++)
	{
		for(j = 0; j< WIDTH_OF_DISPLAY; j++)
			printf("%c", screen[i][j]);
		printf("\n");
	}
}