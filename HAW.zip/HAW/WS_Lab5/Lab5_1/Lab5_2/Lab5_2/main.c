#define _CRT_SECURE_NO_WARNINGS

#include "functions.h"

void main() 
{

	char dice [POSSIBLE_DICE_VALUES][HIGHT_OF_ONE_DIE][WIDTH_OF_DICE]=      {
		{{" _________ \0"},
		 {"|         |\0"},
		 {"|         |\0"},
		 {"|    O    |\0"},
		 {"|         |\0"},
		 {"|_________|\0"}},
		{{" _________ \0"},
		 {"|         |\0"},
		 {"| O       |\0"},
		 {"|         |\0"},
		 {"|       O |\0"},
		 {"|_________|\0"}},
		{{" _________ \0"},
		 {"|         |\0"},
		 {"| O       |\0"},
		 {"|    O    |\0"},
		 {"|       O |\0"},
		 {"|_________|\0"}},
		{{" _________ \0"},
		 {"|         |\0"},
		 {"| O     O |\0"},
		 {"|         |\0"},
		 {"| O     O |\0"},
		 {"|_________|\0"}},
		{{" _________ \0"},
		 {"|         |\0"},
		 {"| O     O |\0"},
		 {"|    O    |\0"},
		 {"| O     O |\0"},
		 {"|_________|\0"}},
 		{{" _________ \0"},
		 {"|         |\0"},
		 {"| O  O  O |\0"},
		 {"|         |\0"},
		 {"| O  O  O |\0"},
		 {"|_________|\0"}},
	};

	int three_different_throws[NUMBER_OF_DICE]={0};
	int i, counter_doubles = 0, counter_triplets = 0;
	char choice;

	//----------------------------------------------------------------
	
	//generate randomly three dice values
	srand((unsigned int)time(NULL));
	while(1)
	{
		for (i = 0; i < NUMBER_OF_DICE; i++)
			three_different_throws[i] = rand()%6;

	// throw three times and display result on screen using display function
		display(dice, three_different_throws);
		
	// count and display number of doubles and triplets		
		counter_triplets += check_for_triplets(three_different_throws);
		counter_doubles += check_for_doubles(three_different_throws);
		printf("\n***doubles %d *** triplets %d ***\n\n", counter_doubles, counter_triplets);
		//Sleep(1000);

		printf("One more time? - Please press Enter!\n");
		printf("Terminate the program? \t Termination of the program is 'e' or 'E'.\n");
		fflush(stdin);
		scanf("%c", &choice);
		if (choice == 'e' || choice == 'E')
			break;
	}

	system("pause");
}