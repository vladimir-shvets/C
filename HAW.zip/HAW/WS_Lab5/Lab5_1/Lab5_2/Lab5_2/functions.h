#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>


#define NUMBER_OF_DICE 3
#define WIDTH_OF_DICE 13
#define HIGHT_OF_ONE_DIE 6
#define POSSIBLE_DICE_VALUES 6
#define HIGHT_OF_DISPLAY 6
#define WIDTH_OF_DISPLAY (3*WIDTH_OF_DICE)

int check_for_triplets(int *);
int check_for_doubles(int *);
void display( char dice [] [HIGHT_OF_ONE_DIE] [WIDTH_OF_DICE], int three_different_throws[]);