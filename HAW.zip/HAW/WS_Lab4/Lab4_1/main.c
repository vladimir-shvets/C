#define _CRT_NO_SECURE_WARNINGS

#include <stdlib.h>
#include <stdio.h>

void multiple_entry_remover(int [], int*);
void print_final_list(int [], int*);

int main()
{
	//int field[] = {1, 2, 2, 1, 1, 1, 3, 1, 2, 3, 2, 1};
	int field[] = {1, 1, 1, 1, 1,1,1,1,1,1,1,1, 1};
	int elements = sizeof(field)/sizeof(int);

	//-------------------------------------------------------

	printf("=====================================\n");
	printf("elements = %d\n", elements);
// Now, all multiple-entries will be removed and the number of
// elements will be correspondingly reduced.
	multiple_entry_remover(field, &elements);
// Note : elements now contains ONLY the relevant number of elements
// WITH_OUT multiple entries
	printf("=====================================\n");
	print_final_list(field, &elements);
	
	system("pause");
	return 0;
}

void multiple_entry_remover(int arr[], int* num_elems)
{
	int i=0, j, k;

	//-----------------------------------------------------

	while( i < *num_elems)
	{
		j = i+1;
		while( j< *num_elems)
		{
			while (arr[j] == arr[i])
			{
				k = j;
				*num_elems -= 1;
				while (k < *num_elems)
				{
					arr[k] = arr[k+1];
					k++;
				}
				arr[k] = -1;
			}
			j++;
		}
		i++;
	}
}
void print_final_list(int arr[], int* num_elems)
{
	int i;
	
	//----------------------------------------------------

	for (i=0; i < *num_elems; i++)
	{
		printf("%d  ", arr[i]);
	}
	printf("\nrelevant nunmber of elements: %d\n", *num_elems);
}