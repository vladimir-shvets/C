﻿#define _CRT_NO_SECURE_WARNINGS

#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#define ARSIZE 26 //26 letters in English alphabet 

void reducing_rubbish(char [], char []);
void inc(int [], char [], char []);
int get_count(char, char[], int []);
int get_total_num_of_all_letters(char []);
int get_num_of_different_letters (int []);
void bubble_sort(int [], char[], int );
void sorted_output(int [], char []);


int main()
{
	char letter[ARSIZE] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'}; // 'a' ... 'z'
	int counter_per_letter[ARSIZE] = {0}; // counter per letter
	//char text_str[] = "azAZ";
	char text_str[] = "adsfasdf34223zAZ";
	char pure_str[100] = " ";
	int total_num_of_all_letters = 0;
	int num_of_different_letters = 0;
	int i;

	//-------------------------------------------------------------------
	
	reducing_rubbish(text_str, pure_str);

	printf("Text under investigation is: \n");
	for (i = 0; i < get_total_num_of_all_letters(pure_str); i++)
	{
		printf("%c", pure_str[i]);
	}

	printf("\n--------------------------------------------------------\n");

	printf("The text contains %d characters.", get_total_num_of_all_letters(pure_str));

	inc(counter_per_letter, pure_str, letter);

	//Sorting the copy of text_str array of chars
	bubble_sort(counter_per_letter, letter, ARSIZE);
	
	printf("\n");
	//Printing out the array with dependence of the the occurrence in sorted order.
	sorted_output(counter_per_letter, letter);
	
	system("pause");
	return 0;
}

void reducing_rubbish(char text_str[], char pure_str[])
{
	int i, j = 0;

	//------------------------------------------------------------------
	
	for (i = 0; i < get_total_num_of_all_letters(text_str); i++)
	{
		if ((int)text_str[i] >= 65 && (int)text_str[i] <= 90)
			{
				pure_str[j] = tolower(text_str[i]);
				j++;
			}
		if ((int)text_str[i] >= 97 && (int)text_str[i] <= 122)
				{
					pure_str[j] = text_str[i];
					j++;
				}
		else continue;	
	}
	pure_str[j] = '\0';
}

void inc(int count[], char pure_str[], char letter[])
{
	int i,j;

	//----------------------------------------------------

		for (i = 0; i < ARSIZE; i++)
		{
			for (j = 0; j < get_total_num_of_all_letters(pure_str); j++)
			{
				if (letter[i] == pure_str[j]) 
					count[i] ++;
			}
		}
}

int get_count(char x, char letter[], int count[])
{
	int i;
	
	//-----------------------------------------------------

	for (i = 0; i < ARSIZE; i++)
	{
		if (letter[i] == x)
			break;
	}
	return count[i];
}

int get_total_num_of_all_letters(char pure_str[])
{
	int len = 0;

	//---------------------------------------------
	
	while (pure_str[len] != '\0')
		len++;
	return len;
}

int get_num_of_different_letters (int count[])
{
	int i, counter = 0;

	//--------------------------------------------

	for (i = 0; i < ARSIZE; i++)
	{
		if (count[i] != 0) counter++;
	}
	return counter;
}

void bubble_sort(int pa[], char letter[], int dimension )
{
	int  ready, i, temp;
	char temp_char;

	//----------------------------------------
	do
	{
		ready = 1;
		for (i = 0; i < dimension - 1; i++)
		{
			if (pa[i] < pa[i+1])
			{
				temp = pa[i];
				pa[i] = pa[i+1];
				pa[i+1] = temp;

				temp_char = letter[i];
				letter[i] = letter[i+1];
				letter[i+1] = temp_char;
				
				ready = 0;
			}
		}
	} while (!ready);
}

void sorted_output(int count[], char letter[])
{
	int i, temp;

	//-----------------------------------------------------------

	for (i = 0; i < get_num_of_different_letters(count); i++)
	{
		printf("letter %c : ", letter[i]);
		temp = get_count(letter[i], letter, count);

		while (temp)
			{
				printf("*");
				temp --;
			}
		printf("\n");
	}
}
