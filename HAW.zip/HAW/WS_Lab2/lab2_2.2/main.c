﻿#define _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>
#include <stdio.h>

int main()
{
	short int x,y;
	signed short result;
	signed char oper1,oper2;


do
{
	printf("\n=============== Lab 2.2 =================\n");
	printf("**Test of some operators:\n");
	printf("Addition\t +\n");
	printf("Increment\t ++\n");

	do
	{
		printf("Enter a valid operator or 'e' or 'E' to terminate program:\n");
		fflush(stdin);
		scanf("%c%c",&oper1,&oper2);
	} while(oper1 != 'e' && oper1 != 'E' && oper1 != '+' && oper2 != '+' );
	
	if(oper1 == '+' && oper2 == '+')
	{
		printf("Input finished, desired operator is ++\n");
		printf("Input values:");
		fflush(stdin);
		scanf("%hd",&x);
		result = ++x;
		printf("result: %hd\n",result);
	}	
	if (oper1 =='+' && oper2 != '+')
	{
		printf("Input finished, desired operator is +\n");
		printf("Input values:");
		fflush(stdin);
		scanf("%hd %hd",&x,&y);
		result = x+y;
		printf("Result=%hd\n",result);
	} 
	 
	} while (oper1 !='e' && oper1 != 'E');

	system("pause");
	return 0;
}

