﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define pi 3.14159265358979323846

int main ()
{
	//setting up all variables:
	//a,b are sides of the triangle, h is the height

	double radius, A_upper_bound, A_lower_bound, angle, a, b, h, angle_radian, average, relative_error;	
	int num_of_triangles;	
	double s;							

	//getting all the information we need from the user:

	printf("enter the radius of the circle\n");
	fflush(stdin);
	scanf("%lf", &radius);
	printf("enter the number of triangles\n");
	fflush(stdin);
	scanf("%d", &num_of_triangles);										

	do //do ... while loop for calculating the number of triangles for relative error = 0.00001 %
{
	//defining the angle:

	angle = 360. / num_of_triangles;		
	angle_radian = pi / 180. * angle;
	
	//square of the circle
		s= pi*pow(radius,2);


		//defining the lower bound:

		h = radius * cos(angle_radian / 2);									
		a = 2. * sqrt(pow(radius,2) - pow(h,2)); 
		A_lower_bound = a * h / 2. * num_of_triangles;

		//defining the upper bound:
		b = 2. * radius * tan(angle_radian / 2);									
		A_upper_bound = radius * b / 2. * num_of_triangles;

		//calculating the average:

		average = (A_lower_bound + A_upper_bound) / 2.;

		//Printing results to the screen:
		printf("S=%f\n",s);
		printf("Value of the upper bound: %lf \n", A_upper_bound);
		printf("Value of the lower bound: %lf \n", A_lower_bound);
		printf("average: %lf \n", average);
	

		//calculating the relative error

		relative_error = fabs((average - s) / s);
		printf("The relative error is: %le \n", relative_error);
	

		printf("Num_of_triangles: %d\n", num_of_triangles);
		num_of_triangles++;

} while (relative_error >= 0.0000001);
	
	system("pause");
	return 0;
}

