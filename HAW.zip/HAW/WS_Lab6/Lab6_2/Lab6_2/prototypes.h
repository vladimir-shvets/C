#include <stdio.h>
#include <stdlib.h>


//------------------- prototypes -----------------------------
double * 	allocate_mem_on_heap_for_vector_1D(int N);
double ** 	allocate_mem_on_heap_for_matrix_2D(int N);
void 		free_mem_on_heap_for_vector_1D(double *);
void 		free_mem_on_heap_for_matrix_2D(double **, int N);

void	 	copy_vector_1D_from_stack_to_heap(
                      double p2vector_1D_on_stack[], 
                      double p2vector_1D_on_heap[], 
					  int N);
void		copy_vector_1D_from_heap_to_stack(
                      double vector_1D_on_heap[], 
                      double vector_1D_on_stack[], 
					  int N);
double *	vector_1D_add(double *p2A, double *p2B, int N);
double		dot_product(double *p2A, double *p2B, int N);
double **	column_vector_1D_times_row_vector_1D(double *p2A, double *p2B, int N);

void		print_vector_1D(double *p2_vec, int N);
void		print_matrix_2D(double **p2p2_matrix, int N);

//------------------------------------------------------------