#include "prototypes.h"

//------------------- main program, variables ---------------------
int main()
{
	double A_on_stack[] = {1, 2, 3, 4};
	double B_on_stack[] = {11, 22, 33, 44};

	double *p2A_on_heap = NULL;
	double *p2B_on_heap = NULL;
	double *p2C_on_heap = NULL;
	double *p2D_on_heap = NULL;
	double dot_prod_val;
	int elements;
	double **p2_matrix2D_on_heap = NULL;

//--------------------------------------------------------------
// code starts:
// calculate the number of elements
	elements = sizeof(A_on_stack)/sizeof(double);
	printf("number of elements in vectors : %d\n\n", elements);

// allocate space for vectors A and B on heap
	p2A_on_heap = allocate_mem_on_heap_for_vector_1D(elements);
	p2B_on_heap = allocate_mem_on_heap_for_vector_1D(elements);

// copy vectors A and B from stack to heap
	copy_vector_1D_from_stack_to_heap(A_on_stack, p2A_on_heap, elements);
	copy_vector_1D_from_stack_to_heap(B_on_stack, p2B_on_heap, elements);

// computes C = A + B. Note : A, B and C are on heap
	p2C_on_heap = vector_1D_add(p2A_on_heap, p2B_on_heap, elements);
	printf("vector addition:\n");
	print_vector_1D(p2C_on_heap, elements);

// computes dot_prod(A, B), A and B on heap, result is a SCALAR value on stack
	dot_prod_val= dot_product(p2A_on_heap, p2B_on_heap, elements);
	printf("\ndot_prod_val = %lf\n\n", dot_prod_val);

// calculate 1D column vector times 1D row vector  --> matrix
	p2_matrix2D_on_heap = column_vector_1D_times_row_vector_1D(p2A_on_heap, p2B_on_heap, elements);
	printf("1D column vector times 1D row vector  :\n");
	print_matrix_2D(p2_matrix2D_on_heap, elements);

// free memory
	free_mem_on_heap_for_vector_1D(p2A_on_heap);
	free_mem_on_heap_for_vector_1D(p2B_on_heap);
	free_mem_on_heap_for_matrix_2D(p2_matrix2D_on_heap, elements);

	system("pause");
	return 0;
} // end of main



