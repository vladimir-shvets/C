#include "prototypes.h"

//allocate memory for 1D array
double * allocate_mem_on_heap_for_vector_1D(int N)
{
	double *vect = NULL;
	vect = (double*)malloc(sizeof(double) * N);

	return vect;
}

//allocate memory for 2D array
double ** allocate_mem_on_heap_for_matrix_2D(int N)
{
	int i;
	double **matr2D = NULL; 
	
	matr2D = (double**) malloc(sizeof( double*) * N ); 
	for (i=0; i<N; i++)
		matr2D[i] = (double*)malloc( sizeof(double)* N);

	return matr2D;
}

//free memory of 1D array
void free_mem_on_heap_for_vector_1D(double *vect)
{
	free(vect);
}

//free memory of 2D array
void free_mem_on_heap_for_matrix_2D(double **matr2D, int N)
{
	int i;

	for (i=0; i<N; i++)
		free(matr2D[i]); // free each allocated row separately
	free(matr2D); 
}

//copy 1D array from stack to heap
void copy_vector_1D_from_stack_to_heap(
                      double p2vector_1D_on_stack[], 
                      double p2vector_1D_on_heap[], 
					  int N)
{
	int i;

	for (i = 0; i < N; i++)
		p2vector_1D_on_heap[i] = p2vector_1D_on_stack[i];
}

//UNCLEAR because we don`t use this function at the main program
//copy 1D array from heap to stack 
void copy_vector_1D_from_heap_to_stack(
                      double vector_1D_on_heap[], 
                      double vector_1D_on_stack[], 
					  int N)
{
	int i;

	for (i = 0; i < N; i++)
		vector_1D_on_stack[i] = vector_1D_on_heap[i];
}

//addition of 2 vectors
double * vector_1D_add(double *p2A, double *p2B, int N)
{
	int i;
	double *p2C = allocate_mem_on_heap_for_vector_1D(N);
	
	for (i = 0; i < N; i++)
		p2C[i] = p2A[i] + p2B[i];

	return p2C;
}

//scalar multiplication of 2 vectors
double dot_product(double *p2A, double *p2B, int N)
{
	double result = 0;
	int i;

	//----------------------------------------------------

	for (i = 0; i < N; i++)
		result += p2A[i]*p2B[i];

	return result;
}

//Column vector multiplied by row vector
double **column_vector_1D_times_row_vector_1D(double *p2A, double *p2B, int N)
{
	double **matr2D = allocate_mem_on_heap_for_matrix_2D(N);

	int i,j;

	//-------------------------------------------------------------------------

	for (i=0; i<N; i++)
	{
		for (j=0; j<N; j++)
			matr2D[i][j] = p2A[i]*p2B[j];
	}

	return matr2D;
}
 //print 1D array on the screen
void print_vector_1D(double *p2_vec, int N)
{
	int i;

	//-------------------------------------------

	for (i=0; i< N; i++)
		printf("%4.2f  ", p2_vec[i]);
}

//print 2D array on the screen
void print_matrix_2D(double **p2p2_matrix, int N)
{
	int i,j;

	//-------------------------------------------------

	for (i=0; i<N; i++)
	{
		for (j=0; j<N; j++)
			printf("%6.2f  ", p2p2_matrix[i][j]);	
		printf("\n");
	}
}