#include <stdlib.h>
#include <stdio.h>

void main()
{
	int i=0, j=0, k=0, planes = 4, rows = 2, columns = 3;
	double ***matr3D = NULL; // this variable

	//---------------------------------------------------------------------------------

	// allocate the memory for 3D array
	matr3D = (double***) malloc(sizeof( double **) * planes); // for array of pointers of pointers
	for (i=0; i<planes; i++)
	{
		matr3D[i] = (double**) malloc( sizeof( double* ) * rows ); // for array of pointers	
		for (j=0; j<rows; j++)
		{
			matr3D[i][j] = (double*) malloc( sizeof( double) * columns ); // for values in each row	
		}
	}

	// fill the 3D-matrix
	for (i=0; i<planes; i++) 
	{
		for (j=0; j<rows; j++)
		{
			for (k=0; k<columns; k++)
			{
				matr3D[i][j][k] = i*1000 + j*10 + k*100;
			}
		}
	}

	// print the 3D-matrix
	for (i=0; i<planes; i++) 
	{
		for (j=0; j<rows; j++)
		{
			for (k=0; k<columns; k++)
			{
				printf("%8.0f", matr3D[i][j][k]);
			}
			printf("\n");
		}
		printf("\n");
	}

	// free each allocation in reverse way columns -> rows -> planes !!
	for (i=0; i<columns; i++)
	{
		for (j=0; j<rows; j++)
		{
			free( matr3D[i][j] ); 
		}
		free( matr3D[i]);
	}
	free( matr3D );

	system("pause");
}