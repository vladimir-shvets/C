#include <stdio.h>
#include <iostream>
#include<string>
using namespace std;

class CBaseString
{
public:
    char ChangeCharReg(unsigned char c);
    string SelectString(string s,string subs);
    int GetStringWeight(string subs);
};
char CBaseString::ChangeCharReg(unsigned char c)
{
    if(c>=65 && c<=90)
        return c+32;
    else if(c>=97 && c<=122)
        return c-32;
    else if(c>=128 && c<=143)
        return c+32;
    else if(c>=144 && c<=159)
        return c+80;
    else if(c>=160 && c<=175)
        return c-32;
    else if(c>=224 && c<=239)
        return c-80;
    else if(c==240)
        return c+1;
    else if(c==241)
        return c-1;
    else
        return c;
}
string CBaseString::SelectString(string s,string subs)
{
    string str;
    int n;
    while((n=s.find(subs))>-1)
    {
        str+=s.substr(0,n);
        str+='('+subs+')';
        s=s.substr(n+subs.length(),s.length()-n-subs.length()+1);
    }
    str+=s;
    return str;
    
}
int CBaseString::GetStringWeight(string subs)
{
    int sum=0;
    for(int i=0;i<subs.length();i++)
    {
        sum+=subs.at(i);
    }
    return sum;
}
class CNasl:public CBaseString
{
	public:
		string func1(string subs)
		{
			string s="";
			for(int i=0;i<subs.length();i++)
			{
				s+=ChangeCharReg(subs.at(i));
			}
			return s;
		}
		string func2(string subs)
		{
			int n=0,i=1,l=0;
			string s,k;
			while(n<subs.length())
			{
				l=n;
				n=subs.find('.',n);
				if(i%2==0)
				{
					s.assign(subs,l,n-l);
					k+=func1(s);
				}
				else
				{
					k+=s.assign(subs,l,n-l);
				}
				i++;
			}
			return k;
		}
		string func3(string subs)
		{
			int n=0,sum=0,l=0,max;
			string s,k;
			while(n<subs.length())
			{
				l=n;
				n=subs.find(' ',n);
				k.assign(subs,l,n-l);
				for(int i=0;i<n;i++)
				{
					if(k.at(i)!='a'&&k.at(i)!='e'&&k.at(i)!='i'&&k.at(i)!='o'&&k.at(i)!='u'&&k.at(i)!='y'&&k.at(i)!='A'&&k.at(i)!='E'&&k.at(i)!='I'&&k.at(i)!='O'&&k.at(i)!='U'&&k.at(i)!='Y')
						sum++;
				}
				if(sum>max)
				{
					max=sum;
					s=k;
				}
			}
			return s;
		}
};
void main()
{
	CNasl C;
	string s="Hello world.";
	s=C.func1(s);
//	cout<<s<<endl;
	s=C.func1(s);
//	s=C.func2(s);
//	s=C.func3(s);
	cout<<s<<endl;
}