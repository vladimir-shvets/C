#include <stdio.h>
#include <iostream>
using namespace std;

class CCube
{	
	int pArr[5][5][5];
public:
		void Task1()
		{
			int n=5;
			int i,j,k,c=1;
			for(j=0;j<5;j++)
			{
				for(i=0;i<3;i++)
				{
					for(k=0;k<4;k++)
					{
						pArr[i][j][k]=c;
						c++;
					}
				}
			}
			return;
		}
		void ShowCube(char x,char y,char z)
		{
			char i,j,k;
			printf("\r\n\r\n\r\n");
			for(k=z-1;k>=0;k--)
			{
				for(j=0;j<y;j++)
				{
					for(int l=5-j;l>=1;l--)
						printf("   ");
					for(i=0;i<x;i++)
						printf("%0.3i     ",pArr[i][j][k]);
					printf("\r\n");
				}
				printf("\r\n\r\n\r\n");
			}
		}
		void Task2()
		{
			int x,i;
			for(i=4;i>=1;i--)
			{
				for(x=0;x<3;x++)
				{
					pArr[x][i][i-1]=0;
				}
			}
		}
		void Task3()
		{
			int x,y,z=2;
			for(y=0;y<5;y++)
			{
				for(x=0;x<3;x++)
				{
					printf("%0.3i     ",pArr[x][y][z]);
					printf("\r\n");
				}
			}
		}
}C;

void main()
{
	C.Task1();
	C.ShowCube(3,5,4);
	C.Task2();
	C.ShowCube(3,5,4);
	C.Task3();
}