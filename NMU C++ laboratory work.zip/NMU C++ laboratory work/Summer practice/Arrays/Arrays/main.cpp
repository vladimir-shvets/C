#include <stdio.h>
	int i=5;
	int j=5;
	int k=0; 
	int a=1;

void main()
{
	int N=5;
	scanf("%i",&N);						
	int Arr[10000];
	Func1(*Arr); 
	for(k=0;k<N;k++)
	{
		for(j=0;j<N;j++)
		{
			for(i=0;i<N;i++)
				*(Arr+N*N*k+N*j+i)=0;
		}
	}
	for(k=0;k<N;k++)
	{
		for(int d=(N*2);d>-1;d--)
		{
			for(int i=N-1;i>N-k-2;i--)
			{
				for(int j=k;j>-1;j--)
				{
					if(i+j==d)
					{	
						*(Arr+k*N*N+i*N+j)=a++;
					}
				}
			}		
		}
	}
	for(k=N-1;k>=0;k--)
	{
		for(j=0;j<N;j++)
		{
			for(int l=N-j;l>=1;l--)
				printf("   ");
			for(i=0;i<N;i++)
				printf("%0.3i     ",*(Arr+N*N*k+N*j+i));
			printf("\r\n");
		}
		printf("\r\n\r\n\r\n");
	}
}