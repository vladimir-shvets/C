#include <stdio.h>

int i;
int j;
int k; 
int a=1;
int *Arr;

void Func1(int N)
{
	for(k=0;k<N;k++)
	{
		for(j=0;j<N;j++)
		{
			for(i=0;i<N;i++)
				*(Arr+N*N*k+N*j+i)=0;
		}
	}
}

void Func2(int N)
{
	for(k=0;k<N;k++)
	{
		for(int d=(N*2);d>-1;d--)
		{
			for(int i=N-1;i>N-k-2;i--)
			{
				for(int j=k;j>-1;j--)
				{
					if(i+j==d)
					{	
						*(Arr+k*N*N+i*N+j)=a++;
					}
				}
			}		
		}
	}	
}

void ShowCube(int N)
{
	for(k=N-1;k>=0;k--)
	{
		for(j=0;j<N;j++)
		{
			for(int l=N-j;l>=1;l--)
				printf("   ");
			for(i=0;i<N;i++)
				printf("%0.3i     ",*(Arr+N*N*k+N*j+i));
			printf("\r\n");
		}
		printf("\r\n\r\n\r\n");
	}
}

void main()
{
	int N;
	while(N!=-1)
	{
		a=1;
		scanf("%i",&N);
		Arr=new int[N*N*N];
		if(N<0)
			N=-1;
		else
		{
			Func1(N);
			Func2(N);
			ShowCube(N);
		}
	}
}