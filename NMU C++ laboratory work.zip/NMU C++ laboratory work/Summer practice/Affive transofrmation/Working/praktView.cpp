// praktView.cpp : implementation of the CPraktView class
//

#include "stdafx.h"
#include "prakt.h"
#include "math.h"
#include "praktDoc.h"
#include "praktView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPraktView

IMPLEMENT_DYNCREATE(CPraktView, CView)

BEGIN_MESSAGE_MAP(CPraktView, CView)
	//{{AFX_MSG_MAP(CPraktView)
	ON_COMMAND(ID_on1, Onon1)
	ON_COMMAND(ID_on2, Onon2)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPraktView construction/destruction

CPraktView::CPraktView()
{
	// TODO: add construction code here
	Flag=0;
	x0=300;
	y0=200;
	p[0].x=10;
	p[0].y=40;
	p[1].x=10;
	p[1].y=70;
	p[2].x=50;
	p[2].y=50;
	p[3].x=60;
	p[3].y=90;
	p[4].x=70;
	p[4].y=50;
	p[5].x=100;
	p[5].y=20;
	p[6].x=50;
	p[6].y=40;
	p[7].x=50;
	p[7].y=10;
	p[8].x=10;
	p[8].y=40;
	for(int i=0;i<9;i++)
	{
		q[i]=p[i];
	}
	for(i=0;i<3;i++)
		for(int j=0;j<3;j++)
			if(i==j)
				Rez[i][j]=1;
			else
				Rez[i][j]=0;
}

CPraktView::~CPraktView()
{
}

BOOL CPraktView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CPraktView drawing

void CPraktView::OnDraw(CDC* pDC)
{
	char* r1=new char;
	char* r2=new char;
	if(Flag==0)
	{
		x0=210;
		y0=140;
		CPen redPen(0,1,RGB(235,165,161));
		CPen olden(0,1,RGB(250,250,250));
		CBrush br=RGB(213,165,255);
		pDC->SetBkColor(RGB(213,165,255));
		pDC->SelectObject(br);
		pDC->Rectangle(0,0,1400,1400);
		pDC->SelectObject(redPen);
		int x=0,y=0;
		while(x<1200)
		{
			pDC->MoveTo(x,y);
			pDC->LineTo(x,1200);
			x+=3;
		}
		while(y<1200)
		{
			pDC->MoveTo(0,y);
			pDC->LineTo(1200,y);
			y+=3;
		}
		pDC->SelectObject(olden);
		pDC->MoveTo(x0,y0-90);
		pDC->LineTo(x0,y0+40);
		pDC->MoveTo(x0-50,y0);
		pDC->LineTo(x0+150,y0);
		pDC->MoveTo(x0,y0);
		pDC->MoveTo(x0-3,y0-80);
		pDC->LineTo(x0,y0-90);
		pDC->LineTo(x0+3,y0-80);
		pDC->MoveTo(x0+140,y0-3);
		pDC->LineTo(x0+150,y0);
		pDC->LineTo(x0+140,y0+3);
		//
		pDC->TextOut(x0+10,y0-90,"Y");
		pDC->TextOut(x0+140,y0+10,"X");
		CPen Pen(0,1,RGB(41,255,30));
		pDC->SelectObject(Pen);	
		POINT pt[12];
		int ky=0;
		int kx=-100;
		for(int i=0;i<9;i++)
		{
			pt[i].x=x0+p[i].x;
			pt[i].y=y0-p[i].y;
			if(i!=8)
			{
				itoa(pt[i].x,r1,10);
				itoa(pt[i].y,r2,10);
				pDC->TextOut(725+kx,350+ky,r1);
				pDC->TextOut(755+kx,350+ky,r2);
				ky+=20;
			}
		}
		pDC->TextOut(pt[0].x-8,pt[0].y-9,"A");
		pDC->TextOut(pt[1].x-10,pt[1].y-15,"B");
		pDC->TextOut(pt[2].x,pt[2].y-15,"C");
		pDC->TextOut(pt[3].x-10,pt[3].y+5,"D");
		pDC->TextOut(pt[4].x+5,pt[4].y+5,"E");
		pDC->TextOut(pt[5].x+5,pt[5].y+5,"F");
		pDC->TextOut(pt[6].x+5,pt[6].y+5,"G");
		pDC->TextOut(pt[7].x+5,pt[7].y+5,"H");
		pDC->TextOut(600,350,"A - (");
		pDC->TextOut(680,350,")");
		pDC->TextOut(600,370,"B - (");
		pDC->TextOut(680,370,")");
		pDC->TextOut(600,390,"C - (");
		pDC->TextOut(680,390,")");
		pDC->TextOut(600,410,"D - (");
		pDC->TextOut(680,410,")");
		pDC->TextOut(600,430,"E - (");
		pDC->TextOut(680,430,")");
		pDC->TextOut(600,450,"F - (");
		pDC->TextOut(680,450,")");
		pDC->TextOut(600,470,"G - (");
		pDC->TextOut(680,470,")");
		pDC->TextOut(600,490,"H - (");
		pDC->TextOut(680,490,")");
		pDC->Polyline(pt,9);
		//////////////////////////////////////////////
		x0=210;
		y0=290;
		pDC->SelectObject(br);
		pDC->SelectObject(olden);
		pDC->MoveTo(x0,y0-90);
		pDC->LineTo(x0,y0+40);
		pDC->MoveTo(x0-50,y0);
		pDC->LineTo(x0+150,y0);
		pDC->MoveTo(x0,y0);
		
		pDC->MoveTo(x0-3,y0-80);
		pDC->LineTo(x0,y0-90);
		pDC->LineTo(x0+3,y0-80);
		pDC->MoveTo(x0+140,y0-3);
		pDC->LineTo(x0+150,y0);
		pDC->LineTo(x0+140,y0+3);
		//
		pDC->TextOut(x0+10,y0-90,"Y");
		pDC->TextOut(x0+140,y0+10,"X");
		pDC->SelectObject(Pen);
		//float M2[3][3]={{1,0.2,0},{0.1,1,0},{0,0,1}};
		//AffineMatrixMult(&M2[0][0],&Rez[0][0],&Rez[0][0],3);
		for(i=0;i<9;i++)
		{
			q[i].x=p[i].x+p[i].y*0.15;
			q[i].y=-p[i].x*0.2+p[i].y;
		}
		ky=0;kx=0;
		for(i=0;i<9;i++)
		{
			pt[i].x=x0+q[i].x;
			pt[i].y=y0-q[i].y;
			if(i!=8)
			{
				itoa(pt[i].x,r1,10);
				itoa(pt[i].y,r2,10);
				pDC->TextOut(735+kx,350+ky,r1);
				pDC->TextOut(765+kx,350+ky,r2);
				ky+=20;
			}
		}
		pDC->TextOut(pt[0].x-8,pt[0].y-9,"A1");
		pDC->TextOut(pt[1].x-10,pt[1].y-15,"B1");
		pDC->TextOut(pt[2].x,pt[2].y-15,"C1");
		pDC->TextOut(pt[3].x-10,pt[3].y+5,"D1");
		pDC->TextOut(pt[4].x+5,pt[4].y+5,"E1");
		pDC->TextOut(pt[5].x+5,pt[5].y+5,"F1");
		pDC->TextOut(pt[6].x+5,pt[6].y+5,"G1");
		pDC->TextOut(pt[7].x+5,pt[7].y+5,"H1");
		pDC->TextOut(700,350,"A1 - (");
		pDC->TextOut(790,350,")");
		pDC->TextOut(700,370,"B1 - (");
		pDC->TextOut(790,370,")");
		pDC->TextOut(700,390,"C1 - (");
		pDC->TextOut(790,390,")");
		pDC->TextOut(700,410,"D1 - (");
		pDC->TextOut(790,410,")");
		pDC->TextOut(700,430,"E1 - (");
		pDC->TextOut(790,430,")");
		pDC->TextOut(700,450,"F1 - (");
		pDC->TextOut(790,450,")");
		pDC->TextOut(700,470,"G1 - (");
		pDC->TextOut(790,470,")");
		pDC->TextOut(700,490,"H1 - (");
		pDC->TextOut(790,490,")");
		pDC->Polyline(pt,9);
		//////////////////////////////////////////////////////
		x0=440;
		y0=140;
		pDC->SelectObject(br);
		pDC->SelectObject(olden);
		pDC->MoveTo(x0,y0-90);
		pDC->LineTo(x0,y0+40);
		pDC->MoveTo(x0-50,y0);
		pDC->LineTo(x0+150,y0);
		pDC->MoveTo(x0,y0);
		
		pDC->MoveTo(x0-3,y0-80);
		pDC->LineTo(x0,y0-90);
		pDC->LineTo(x0+3,y0-80);
		pDC->MoveTo(x0+140,y0-3);
		pDC->LineTo(x0+150,y0);
		pDC->LineTo(x0+140,y0+3);
		//
		pDC->TextOut(x0+10,y0-90,"Y");
		pDC->TextOut(x0+140,y0+10,"X");
		pDC->SelectObject(Pen);
		//float M1[3][3]={{0.95,0,0},{0,1.15,0},{0,0,1}};
		//AffineMatrixMult(&M1[0][0],&Rez[0][0],&Rez[0][0],3);
		for(i=0;i<9;i++)
		{
			q[i].x=1.2*p[i].x;
			q[i].y=0.7*p[i].y;
		}
		ky=0;kx=100;
		for(i=0;i<9;i++)
		{
			pt[i].x=x0+q[i].x;
			pt[i].y=y0-q[i].y;
			if(i!=8)
			{
				itoa(pt[i].x,r1,10);
				itoa(pt[i].y,r2,10);
				pDC->TextOut(735+kx,350+ky,r1);
				pDC->TextOut(765+kx,350+ky,r2);
				ky+=20;
			}
		}
		pDC->TextOut(pt[0].x-8,pt[0].y-9,"A2");
		pDC->TextOut(pt[1].x-10,pt[1].y-15,"B2");
		pDC->TextOut(pt[2].x,pt[2].y-15,"C2");
		pDC->TextOut(pt[3].x-10,pt[3].y+5,"D2");
		pDC->TextOut(pt[4].x+5,pt[4].y+5,"E2");
		pDC->TextOut(pt[5].x+5,pt[5].y+5,"F2");
		pDC->TextOut(pt[6].x+5,pt[6].y+5,"G2");
		pDC->TextOut(pt[7].x+5,pt[7].y+5,"H2");
		pDC->TextOut(800,350,"A2 - (");
		pDC->TextOut(890,350,")");
		pDC->TextOut(800,370,"B2 - (");
		pDC->TextOut(890,370,")");
		pDC->TextOut(800,390,"C2 - (");
		pDC->TextOut(890,390,")");
		pDC->TextOut(800,410,"D2 - (");
		pDC->TextOut(890,410,")");
		pDC->TextOut(800,430,"E2 - (");
		pDC->TextOut(890,430,")");
		pDC->TextOut(800,450,"F2 - (");
		pDC->TextOut(890,450,")");
		pDC->TextOut(800,470,"G2 - (");
		pDC->TextOut(890,470,")");
		pDC->TextOut(800,490,"H2 - (");
		pDC->TextOut(890,490,")");
		pDC->Polyline(pt,9);
		////////////////////////////////////////////
		x0=440;
		y0=290;
		pDC->SelectObject(br);
		pDC->SelectObject(olden);
		pDC->MoveTo(x0,y0-90);
		pDC->LineTo(x0,y0+40);
		pDC->MoveTo(x0-50,y0);
		pDC->LineTo(x0+150,y0);
		pDC->MoveTo(x0,y0);
		
		pDC->MoveTo(x0-3,y0-80);
		pDC->LineTo(x0,y0-90);
		pDC->LineTo(x0+3,y0-80);	
		pDC->MoveTo(x0+140,y0-3);
		pDC->LineTo(x0+150,y0);
		pDC->LineTo(x0+140,y0+3);
		//
		pDC->TextOut(x0-15,y0-90,"Y");
		pDC->TextOut(x0+140,y0+10,"X");
		pDC->SelectObject(Pen);
		//float M[3][3]={{1,0,-15},{0,1,10},{0,0,1}};
		//AffineMatrixMult(&M[0][0],&Rez[0][0],&Rez[0][0],3);
		for(i=0;i<9;i++)
		{
			q[i].x=p[i].x+16;
			q[i].y=p[i].y-20;
		}
		ky=0;kx=200;
		for(i=0;i<9;i++)
		{
				pt[i].x=x0+q[i].x;
				pt[i].y=y0-q[i].y;
				if(i!=8)
			{
				itoa(pt[i].x,r1,10);
				itoa(pt[i].y,r2,10);
				pDC->TextOut(735+kx,350+ky,r1);
				pDC->TextOut(765+kx,350+ky,r2);
				ky+=20;
			}
		}
		pDC->TextOut(pt[0].x-8,pt[0].y-9,"A3");
		pDC->TextOut(pt[1].x-10,pt[1].y-15,"B3");
		pDC->TextOut(pt[2].x,pt[2].y-15,"C3");
		pDC->TextOut(pt[3].x-10,pt[3].y+5,"D3");
		pDC->TextOut(pt[4].x+5,pt[4].y+5,"E3");
		pDC->TextOut(pt[5].x+5,pt[5].y+5,"F3");
		pDC->TextOut(pt[6].x+5,pt[6].y+5,"G3");
		pDC->TextOut(pt[7].x+5,pt[7].y+5,"H3");
		pDC->TextOut(900,350,"A3 - (");
		pDC->TextOut(990,350,")");
		pDC->TextOut(900,370,"B3 - (");
		pDC->TextOut(990,370,")");
		pDC->TextOut(900,390,"C3 - (");
		pDC->TextOut(990,390,")");
		pDC->TextOut(900,410,"D3 - (");
		pDC->TextOut(990,410,")");
		pDC->TextOut(900,430,"E3 - (");
		pDC->TextOut(990,430,")");
		pDC->TextOut(900,450,"F3 - (");
		pDC->TextOut(990,450,")");
		pDC->TextOut(900,470,"G3 - (");
		pDC->TextOut(990,470,")");
		pDC->TextOut(900,490,"H3 - (");
		pDC->TextOut(990,490,")");
		pDC->Polyline(pt,9);
		/////////////////////////////////////////////////////
		x0=730;
		y0=200;
		pDC->SelectObject(br);
		pDC->SelectObject(olden);
		pDC->MoveTo(x0,y0-90);
		pDC->LineTo(x0,y0+40);
		pDC->MoveTo(x0-50,y0);
		pDC->LineTo(x0+150,y0);
		pDC->MoveTo(x0,y0);
		
		pDC->MoveTo(x0-3,y0-80);
		pDC->LineTo(x0,y0-90);
		pDC->LineTo(x0+3,y0-80);
		pDC->MoveTo(x0+140,y0-3);
		pDC->LineTo(x0+150,y0);
		pDC->LineTo(x0+140,y0+3);
		//
		pDC->TextOut(x0+10,y0-90,"Y");
		pDC->TextOut(x0+140,y0+10,"X");
		pDC->SelectObject(Pen);
		//float M4[3][3]={{cos(-75*3.14/180),-sin(-75*3.14/180),0},{sin(-75*3.14/180),cos(-75*3.14/180),0},{0,0,1}};
		//AffineMatrixMult(&M4[0][0],&Rez[0][0],&Rez[0][0],3);
		for(i=0;i<9;i++)
		{
			q[i].x=p[i].x*cos(-155*3.14/180)-p[i].y*sin(-155*3.14/180);
			q[i].y=p[i].x*sin(-155*3.14/180)+p[i].y*cos(-155*3.14/180);
		}
		ky=-200;kx=200;
		for(i=0;i<9;i++)
		{
			pt[i].x=x0+q[i].x;
			pt[i].y=y0-q[i].y;
			if(i!=8)
			{
				itoa(pt[i].x,r1,10);
				itoa(pt[i].y,r2,10);
				pDC->TextOut(735+kx,250+ky,r1);
				pDC->TextOut(765+kx,250+ky,r2);
				ky+=20;
			}
		}
		pDC->TextOut(pt[0].x-8,pt[0].y-9,"A4");
		pDC->TextOut(pt[1].x-10,pt[1].y-5,"B4");
		pDC->TextOut(pt[2].x-7,pt[2].y-15,"C4");
		pDC->TextOut(pt[3].x-10,pt[3].y+5,"D4");
		pDC->TextOut(pt[4].x,pt[4].y-2,"E4");
		pDC->TextOut(pt[5].x+5,pt[5].y+5,"F4");
		pDC->TextOut(pt[6].x+5,pt[6].y+5,"G4");
		pDC->TextOut(pt[7].x+5,pt[7].y+5,"H4");
		pDC->TextOut(900,50,"A4 - (");
		pDC->TextOut(990,50,")");
		pDC->TextOut(900,70,"B4 - (");
		pDC->TextOut(990,70,")");
		pDC->TextOut(900,90,"C4 - (");
		pDC->TextOut(990,90,")");
		pDC->TextOut(900,110,"D4 - (");
		pDC->TextOut(990,110,")");
		pDC->TextOut(900,130,"E4 - (");
		pDC->TextOut(990,130,")");
		pDC->TextOut(900,150,"F4 - (");
		pDC->TextOut(990,150,")");
		pDC->TextOut(900,170,"G4 - (");
		pDC->TextOut(990,170,")");
		pDC->TextOut(900,190,"H4 - (");
		pDC->TextOut(990,190,")");
		pDC->Polyline(pt,9);
		}
	if(Flag==1)
	{
		x0=380;
		y0=150;	
		CPen redPen(0,1,RGB(235,165,161));
		CPen olden(0,1,RGB(250,250,250));
		CBrush br=RGB(213,165,255);
		pDC->SetBkColor(RGB(213,165,255));
		pDC->SelectObject(br);
		pDC->Rectangle(0,0,1400,1400);
		pDC->SelectObject(redPen);
		int x=0,y=0;
		while(x<1200)
		{
			pDC->MoveTo(x,y);
			pDC->LineTo(x,1200);
			x+=5;
		}
		while(y<1200)
		{
			pDC->MoveTo(0,y);
			pDC->LineTo(1200,y);
			y+=5;
		}
		pDC->SelectObject(olden);
		pDC->SetBkColor(RGB(53,255,211));
		pDC->MoveTo(x0,y0-90);
		pDC->LineTo(x0,y0+40);
		pDC->MoveTo(x0-50,y0);
		pDC->LineTo(x0+150,y0);
		pDC->MoveTo(x0,y0);
		pDC->MoveTo(x0-3,y0-80);
		pDC->LineTo(x0,y0-90);
		pDC->LineTo(x0+3,y0-80);
		pDC->MoveTo(x0+140,y0-3);
		pDC->LineTo(x0+150,y0);
		pDC->LineTo(x0+140,y0+3);
		//
		pDC->TextOut(x0+10,y0-90,"Y");
		pDC->TextOut(x0+140,y0+10,"X");
		CPen Pen(1,1,RGB(41,255,30));
		CPen Pen1(0,1,RGB(41,255,30));
		pDC->SelectObject(Pen);	
		
		POINT pt[12];
		//
		int ky=0;
		int x1=0,y1=0;
		for(int i=0;i<9;i++)
		{
			pt[i].x=x0+p[i].x;
			pt[i].y=y0-p[i].y;
			if(i<8)
			{
				itoa(pt[i].x,r1,10);
				itoa(pt[i].y,r2,10);
				pDC->TextOut(625,250+ky,r1);
				pDC->TextOut(655,250+ky,r2);
				ky+=20;
				x1+=p[i].x;
				y1+=p[i].y;
			}
		}
		x1/=8;
		y1/=8;
		pDC->TextOut(pt[0].x-8,pt[0].y-9,"A");
		pDC->TextOut(pt[1].x-10,pt[1].y-15,"B");
		pDC->TextOut(pt[2].x-5,pt[2].y-15,"C");
		pDC->TextOut(pt[3].x-5,pt[3].y,"D");
		pDC->TextOut(pt[4].x-3,pt[4].y-15,"E");
		pDC->TextOut(pt[5].x,pt[5].y-15,"F");
		pDC->TextOut(pt[6].x,pt[6].y-7,"G");
		pDC->TextOut(pt[7].x,pt[7].y,"H");
		pDC->TextOut(600,250,"A - (");
		pDC->TextOut(680,250,")");
		pDC->TextOut(600,270,"B - (");
		pDC->TextOut(680,270,")");
		pDC->TextOut(600,290,"C - (");
		pDC->TextOut(680,290,")");
		pDC->TextOut(600,310,"D - (");
		pDC->TextOut(680,310,")");
		pDC->TextOut(600,330,"E - (");
		pDC->TextOut(680,330,")");
		pDC->TextOut(600,350,"F - (");
		pDC->TextOut(680,350,")");
		pDC->TextOut(600,370,"G - (");
		pDC->TextOut(680,370,")");
		pDC->TextOut(600,390,"H - (");
		pDC->TextOut(680,390,")");
		pDC->Polyline(pt,9);
		pDC->SelectObject(Pen1);
		float a;
		//
		float b;
		//
		a=45*3.14/180;
		//
		x=0;
		//
		//float M1[3][3]={{1,0,-x},{0,1,-y},{0,0,1}};//�����������
		//float M2[3][3]={{1,0,x},{0,1,y},{0,0,1}};
		//float M3[3][3]={{cos(a),-sin(a),0},{sin(a),cos(a),0},{0,0,1}};
		//
		float R[3][3];
		//
		//AffineMatrixMult(&M1[0][0],&Rez[0][0],&Rez[0][0],3);
		//AffineMatrixMult(&M3[0][0],&Rez[0][0],&Rez[0][0],3);
		//AffineMatrixMult(&M2[0][0],&Rez[0][0],&Rez[0][0],3);
		//
		for(i=0;i<9;i++)
		{
			p[i].x-=x1;
			p[i].y-=y1;
		}
		for(i=0;i<9;i++)
		{
			q[i].x=p[i].x*0.8+30;
			q[i].y=p[i].y*0.8+20;
		}
		ky=0;
		for(i=0;i<9;i++)
		{
			pt[i].x=x0+q[i].x+x1;
			pt[i].y=y0-q[i].y-y1;
			if(i<8)
			{
				itoa(pt[i].x,r1,10);
				itoa(pt[i].y,r2,10);
				pDC->TextOut(735,250+ky,r1);
				pDC->TextOut(765,250+ky,r2);
				ky+=20;
			}
		}
		pDC->TextOut(pt[0].x-8,pt[0].y+3,"A1");
		pDC->TextOut(pt[1].x-3,pt[1].y,"B1");
		pDC->TextOut(pt[2].x,pt[2].y-15,"C1");
		pDC->TextOut(pt[3].x-3,pt[3].y-5,"D1");
		pDC->TextOut(pt[4].x,pt[4].y-18,"E1");
		pDC->TextOut(pt[5].x+5,pt[5].y+5,"F1");
		pDC->TextOut(pt[6].x+5,pt[6].y+5,"G1");
		pDC->TextOut(pt[7].x+5,pt[7].y+5,"H1");
		pDC->TextOut(700,250,"A1 - (");
		pDC->TextOut(790,250,")");
		pDC->TextOut(700,270,"B1 - (");
		pDC->TextOut(790,270,")");
		pDC->TextOut(700,290,"C1 - (");
		pDC->TextOut(790,290,")");
		pDC->TextOut(700,310,"D1 - (");
		pDC->TextOut(790,310,")");
		pDC->TextOut(700,330,"E1 - (");
		pDC->TextOut(790,330,")");
		pDC->TextOut(700,350,"F1 - (");
		pDC->TextOut(790,350,")");
		pDC->TextOut(700,370,"G1 - (");
		pDC->TextOut(790,370,")");
		pDC->TextOut(700,390,"H1 - (");
		pDC->TextOut(790,390,")");
		pDC->Polyline(pt,9);
	}
	CPraktDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CPraktView printing

BOOL CPraktView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CPraktView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CPraktView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CPraktView diagnostics

#ifdef _DEBUG
void CPraktView::AssertValid() const
{
	CView::AssertValid();
}

void CPraktView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CPraktDoc* CPraktView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPraktDoc)));
	return (CPraktDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPraktView message handlers

void CPraktView::Onon1() 
{
	// TODO: Add your command handler code here
	Flag=0;
	Invalidate();
}

void CPraktView::Onon2() 
{
	// TODO: Add your command handler code here
	Flag=1;
	Invalidate();
}
void CPraktView::AffineMatrixMult(float *M1, float *M2, float *R, int ij)
{
	//
	float *M;
	M=new float [ij*ij];
	//
	int i,j,k;
	for(i=0;i<ij;i++)
		for(j=0;j<ij;j++)
			*(M+3*i+j)=0;
		//
	for(i=0;i<ij;i++)
		for(j=0;j<ij;j++)
			for(k=0;k<ij;k++)
				*(M+3*i+j)+=*(M1+3*i+k)**(M2+3*k+j);
			//
	/*for(i=0;i<ij;i++)
		*(R+i)=*(M+i);*/
	for(i=0;i<ij;i++)
		for(j=0;j<ij;j++)
			*(R+3*i+j)=*(M+3*i+j);
	//
	delete []M;
}
