// praktDoc.cpp : implementation of the CPraktDoc class
//

#include "stdafx.h"
#include "prakt.h"

#include "praktDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPraktDoc

IMPLEMENT_DYNCREATE(CPraktDoc, CDocument)

BEGIN_MESSAGE_MAP(CPraktDoc, CDocument)
	//{{AFX_MSG_MAP(CPraktDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPraktDoc construction/destruction

CPraktDoc::CPraktDoc()
{
	// TODO: add one-time construction code here

}

CPraktDoc::~CPraktDoc()
{
}

BOOL CPraktDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CPraktDoc serialization

void CPraktDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CPraktDoc diagnostics

#ifdef _DEBUG
void CPraktDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPraktDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPraktDoc commands
