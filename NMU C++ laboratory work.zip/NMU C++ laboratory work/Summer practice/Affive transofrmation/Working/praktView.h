// praktView.h : interface of the CPraktView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PRAKTVIEW_H__E372B412_9018_461A_857C_BA72B4A27650__INCLUDED_)
#define AFX_PRAKTVIEW_H__E372B412_9018_461A_857C_BA72B4A27650__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPraktView : public CView
{
protected: // create from serialization only
	CPraktView();
	DECLARE_DYNCREATE(CPraktView)

// Attributes
public:
	int Flag;
	POINT p[9];
	POINT q[9];
	int x0,y0;
	float Difx;
	float Dify;
	POINT vector;
	float Big_Low;
	int Angle;
	int x,y;
	float Rez[3][3];
	void AffineMatrixMult(float *M1, float *M2, float *R, int ij);
	CPraktDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPraktView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPraktView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPraktView)
	afx_msg void Onon1();
	afx_msg void Onon2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in praktView.cpp
inline CPraktDoc* CPraktView::GetDocument()
   { return (CPraktDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PRAKTVIEW_H__E372B412_9018_461A_857C_BA72B4A27650__INCLUDED_)
