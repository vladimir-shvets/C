// SpiskiDlg.h : header file
//

#if !defined(AFX_SPISKIDLG_H__F53B060A_6583_431C_8DAC_E440388372E8__INCLUDED_)
#define AFX_SPISKIDLG_H__F53B060A_6583_431C_8DAC_E440388372E8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSpiskiDlg dialog

class CSpiskiDlg : public CDialog
{
// Construction
public:
	struct elem
	{
		elem *pNext;
		elem *pPrev;
		int *pMas;
		CString name;
	};
	elem *pFirst;
	int count;
	elem *pCur;
	elem *pNew;
	elem *pElem;
	elem *pLast;
	int *pArr;
	bool del;

	CSpiskiDlg(CWnd* pParent = NULL);// standard constructor

// Dialog Data
	//{{AFX_DATA(CSpiskiDlg)
	enum { IDD = IDD_SPISKI_DIALOG };
	CListBox	m_shcon;
	CEdit	m_count;
	CEdit	m_chrez;
	CEdit	m_chno;
	CComboBox	m_second;
	CComboBox	m_first;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSpiskiDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSpiskiDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg void ScanFile();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnFirst();
	afx_msg void OnCreate();
	afx_msg void Create(CString namef, CString names);
	afx_msg void ShowConnections();
	afx_msg void DeleteElement(elem *pCur);
	afx_msg void OnCheck();
	afx_msg void OnDelete();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPISKIDLG_H__F53B060A_6583_431C_8DAC_E440388372E8__INCLUDED_)
