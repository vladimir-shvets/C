#include <stdio.h>
#include <iostream>
#include <math.h>
#include <string>
using namespace std;

class CBaseString
{
	public:
		char ChangeCharReg(unsigned char c);
		string SelectString(string s,string subs);
		int GetStringWeight(string subs);
};
char CBaseString::ChangeCharReg(unsigned char c)
{
    if(c>=65 && c<=90)
        return c+32;
    else if(c>=97 && c<=122)
        return c-32;
    else if(c>=128 && c<=143)
        return c+32;
    else if(c>=144 && c<=159)
        return c+80;
    else if(c>=160 && c<=175)
        return c-32;
    else if(c>=224 && c<=239)
        return c-80;
    else if(c==240)
        return c+1;
    else if(c==241)
        return c-1;
    else
        return c;
    
}
string CBaseString::SelectString(string s,string subs)
{
    string str;
    int n;
    while((n=s.find(subs))>-1)
    {
        str+=s.substr(0,n);
        str+='('+subs+')';
        s=s.substr(n+subs.length(),s.length()-n-subs.length()+1);
    }
    str+=s;
    return str;
    
}
int CBaseString::GetStringWeight(string subs)
{
    int sum=0;
    for(int i=0;i<subs.length();i++)
    {
        sum+=subs.at(i);
    }
    return sum;
}

class CTask:public CBaseString
{
	public:
		void fun1(string subs)
		{
			int i;
			for(i=0;i<subs.length();i++)
			{
				char t=subs.at(i);
				if(subs.at(i)==0&&subs.at(i)==1&&subs.at(i)==0&&subs.at(i)==2&&subs.at(i)==3&&subs.at(i)==4&&subs.at(i)==5&&subs.at(i)==6&&subs.at(i)==7&&subs.at(i)==8&&subs.at(i)==9)
				{
					subs.erase(i,1);
				}
			}
		}

};

void main()
{
	CTask C;
	string s="YO";
	s=C.fun1;
	cout<<s<<endl;
}
